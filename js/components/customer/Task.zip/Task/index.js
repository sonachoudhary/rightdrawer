import { Actions, ActionConst } from "react-native-router-flux";
import React, { Component } from "react";
import { connect } from "react-redux";
import {
  View,
  Platform,
  StatusBar,
  Image,
  Dimensions,
  PermissionsAndroid,
  NetInfo,
  AsyncStorage,
  ImageBackground,
  FlatList,
  TouchableWithoutFeedback,
  ScrollView,
  TouchableOpacity
} from "react-native";
import {
  Container,
  Content,
  Header,
  Text,
  Button,
  Icon,
  Title,
  Left,
  Right,
  Item,
  Body,
  Toast,
  Spinner,
  Thumbnail,
  Grid,
  Col,Input
} from "native-base";
import PropTypes from "prop-types";


import { setActiveLogin } from "../../../actions/common/entrypage";
import { barberAppointments } from "../../../actions/common/signin";
import { checkSubscription } from "../../../actions/common/all";
import { acceptAppointment, rejectAppointment, upcomingBooking, setUserLocationNew, startWalkForAppointment, deleteAppointment, getNotificationList } from "../../../actions/common/booking";
import commonColor from "../../../../native-base-theme/variables/commonColor";
import moment from "moment/moment";
import { connectionState } from "../../../actions/network";

import {
  clearEntryPage,
  clearEntryPageFields
} from "../../../actions/common/entrypage";

import styles from "./styles";
const deviceHeight = Dimensions.get("window").height;
const deviceWidth = Dimensions.get('window').width;
import { currentLocationUser } from '../../../actions/driver/home';
import { selectRole } from '../../../actions/common/register';
import GetLocation from 'react-native-get-location'
import { customerAppointments } from "../../../actions/common/signin";

  
function mapStateToProps(state) {
  const getErrormsg = () => {
    if (!state.driver.appState.loginError) {
      return "";
    } else return state.driver.appState.errormsg;
  };

  return {
    user: state.driver.user,
    appointmentList: state.booking.appointmentList,
    profileUrl: state.driver.user.profileUrl,
  };
}

class Task extends Component {
  

  constructor(props) {
    super(props);
    console.log('props==',this.props)
    console.log('props==',props)
    this.state = {
      loading: true,
      data:[{color:"#FFDCD6",Title:'Task Title',class:'class v',Time:'14:00-mon',desc:' this is project based on react react js ,node and angular '},{color:"#FFE5AC",Title:'Task Title',class:'class v',Time:'14:00-mon',desc:' this is project based on react and react js ,node and angular'}],
      data2:[{color:"#FFDCD6",Title:'AssignmentTittle',class:'class v',Time:'14:00-mon',desc:' this is project based on react and react js ,node and angular'},{color:"#FFE5AC",Title:'Assignment Tittle',class:'class v',Time:'14:00-mon',desc:' this is project based on react and react js ,node and angular'},{color:"#E6F6E2",Title:'Assignment Tittle',class:'class v',Time:'14:00-mon',desc:' this is project based on react and react js ,node and angular'},{color:"#E6F6E2",Title:'Assignment Tittle',class:'class v',Time:'14:00-mon',desc:' this is project based on react and react js ,node and angular'},{Title:'Assignment Tittle',class:'class v',Time:'14:00-mon',desc:' this is project based on react and react js ,node and angular'},{Title:'Assignment Tittle',class:'class v',Time:'14:00-mon',desc:' this is project based on react and react js ,node and angular'}],
      data3:[{month:'jan',date:'28',day:'S'},{month:'Feb',date:'29',day:'M'},{month:'March',date:'30',day:'T'},{month:'April',date:'1',day:'W'},{month:'May',date:'2',day:'Th'},{month:'june',date:'3',day:'F'},{month:'july',date:'4',day:'S'},{month:'Aug',date:'5',day:'S'},{month:'Sep'},{month:'Oct'},{month:'Nov'},{month:'Dec'}],
      customer: {
        latitude: this.props.latitude,
        longitude: this.props.longitude
      },
      showModal:false,
      bookings: this.props.appointmentList,
      modalUserName: undefined,
      modalAppointmentId: undefined,
      modalProfileUrl: undefined,
      status:0,
      isCompleted:undefined,
      isConfirmed:undefined
    };
    
  }
  
  componentDidMount(){

    GetLocation.getCurrentPosition({
        enableHighAccuracy: true,
        timeout: 15000,
    })
    .then(location => {
        console.log('getCurrentPosition-',location);
        this.props.setUserLocationNew(location)
    })
    .catch(error => {
        const { code, message } = error;
        console.warn('getCurrentPosition error-', message);
    })
    
    this.props.customerAppointments(this.props.user._id)
  }

  _handleConnectionChange = isConnected => {
    this.props.connectionState({ status: isConnected });
  };
  openInfo(item) {
    console.log('openInfo:',item);
    this.scrollListReftop.scrollTo({x: 0, y: 0, animated: true})
    this.setState({
      showModal: true,
      modalUserName: item.name,
      modalAppointmentId: item.appointment_id,
      services: item.services,
      time: item.time,
      appointment_status: item.status,
      isCompleted: item.isCompleted,
      isConfirmed: item.isConfirmed
    })
  }

  acceptAppointment(id){
    this.setState({
      showModal: false,
    })
    this.props.acceptAppointment(id)
    this.props.barberAppointments(this.props.user._id)
  }

  callBooking(){
    this.props.upcomingBooking(this.props.user._id)
  }

  deleteAppointment(id){
    this.setState({
      showModal: false,
    })
    this.props.deleteAppointment(id);
    this.props.customerAppointments(this.props.user._id)
  }

  startWalk(){  
    this.props.startWalkForAppointment(this.state.modalAppointmentId); 
  }

  renderItem = ({item, index}) => {
    console.log('renderItem:', item.image)
  
     //console.log('renderItem:', path)
    return (
      <TouchableOpacity onPress={()=>Actions.BarberHome()}>
      
           <Text style={styles.textheading2}>{item.month}</Text>  
           <Text style={styles.textheading}>{item.date}</Text> 
           <Text style={styles.textheading2}>{item.day}</Text>  
        </TouchableOpacity>         
               
    )
  };
  renderItem2 = ({item, index}) => {
    console.log('renderItem:', item.image)
  
     //console.log('renderItem:', path)
    return (
      <TouchableOpacity onPress={()=>Actions.Task()} style={{backgroundColor:item.color,margin:10,width:154.13,height:152,borderRadius:10}}>
           
           <Text style={{fontSize:11,marginLeft:10,marginTop:10}}>{item.Time}</Text>  
           <Text style={{fontSize:14,fontWeight:'bold',color:'#000',marginLeft:5}}>{item.Title}</Text> 
            <Text style={{fontSize:11,marginLeft:10,marginTop:10}}>{item.class}</Text> 
            <Text style={{fontSize:11,marginLeft:10,marginTop:10}}>{item.desc}</Text>  
        </TouchableOpacity>         
               
    )
  };
renderItem3 = ({item, index}) => {
    console.log('renderItem:', item.image)
  
     //console.log('renderItem:', path)
    return (
      <View  style={{backgroundColor:item.color,margin:10,width:366.13,height:90,borderRadius:10,flexDirection:'row'}}>
          <View style={{justifyContent:'center',alignItems:'center',borderRightWidth:1,borderRightColor:'lightgray'}}>
           <Text style={{color:"##484347", fontSize:15, marginTop:12 ,fontWeight:'600',marginLeft:10,}}>{item.Time}</Text>  
           
           </View>
           <View style={{width:'75%'}}>
             <View style={{flexDirection:'row',justifyContent:'space-between'}}>
                 <Text style={styles.textheading}>{item.Title}</Text> 
                 <Text style={styles.textheading2}>{item.Time}</Text> 
              </View>
              <Text style={{fontSize:11,marginLeft:10,marginTop:10,marginLeft:30}} >{item.desc}</Text>
           </View> 
        </View>         
               
    )
  };
  
  
  render() { 
   console.log(this.state.data,'data')
    return(
      <Container style={{ backgroundColor: "#470B63" }}>
          
          <View style={{ flex: 1 }}>
            <ScrollView style={{ backgroundColor: "#fff", }} ref={(ref) => { this.scrollListReftop = ref; }}>
              <View style={{ backgroundColor: "#470B63", }}>
              <TouchableWithoutFeedback onPress={() => this.props.navigation.openDrawer() }>
                    <Image                      
                      source={require("../../../../assets/icon/chevron-left.png")}
                      style={{ width:9, height: 18, position:'absolute', left:10 ,marginTop:20,marginLeft:17}}
                    />                          
                  </TouchableWithoutFeedback>
              <View style={{ marginTop:45,}} >
               <View style={{ flexDirection:'row', justifyContent:'space-between',marginLeft:20}}>
                 
                  <View style={{ justifyContent:'center', marginLeft:10 }} >
                    <Text style={{ color:"#E8E8E8", fontSize:18, fontFamily:'Cabin-Bold'  }}>
                      Hi ,{this.props.user.name}
                    </Text> 
                    <Text style={{ color:"#E8E8E8", fontSize:13, fontFamily:'Cabin-Bold'  }}>
                      Here is a list of Task
                    </Text>                    
                  </View>
                   <View style={{flexDirection:'row',justifyContent:'space-between',width:110}}>
                  <Text style={{color:'#fff',marginTop:5}}>Add Task</Text>
                  <TouchableWithoutFeedback onPress={() => this.props.navigation.openDrawer() }>
                   
                    <Image                      
                      source={require("../../../../assets/images/Rectangle_2020.png")}
                      style={{ width:28, height: 28, position:'absolute', right:10 , backgroundColor:'#470B63',}}
                    />                          
                  </TouchableWithoutFeedback>
                  </View>
                </View>

                  
              </View>
               <View style={styles.text} onPress={()=>Actions.CustomerHome()}>
                <FlatList
                   horizontal={true}
                  style={{ margin:10}}
                  data={this.state.data3}
                  extraData={this.state}
                 
                   renderItem={this.renderItem}
                  
                  
                />
                <Text style={{ color:"#000", fontSize:14,fontWeight:'bold',marginLeft:30,marginTop:5,}}>Todays Feeds (2) </Text>
                <View>
                  <FlatList
                  
                  style={{ margin:10}}
                  data={this.state.data}
                  extraData={this.state}
                   renderItem={this.renderItem3}
                  
                />

                </View>
                  <Text style={{ color:"#000", fontSize:14,fontWeight:'bold',marginLeft:30,marginTop:5,}}>Upcoming Tasks</Text>
                  <FlatList
                  horizontal={true}
                  style={{ margin:10}}
                  data={this.state.data2}
                  extraData={this.state}
                   renderItem={this.renderItem2}
                  
                />
                
                
                </View>
                
              </View>     

            </ScrollView>
            

            <View style={{ width: deviceWidth, height: 66, backgroundColor: "#2A3439", flexDirection:'row', justifyContent:'center', marginTop: 20, position:'absolute', bottom:0 }} >
                
                <TouchableWithoutFeedback onPress={() => Actions.CustomerHome()}>
                <View style={{ justifyContent:'center', borderRightWidth:1, borderRightColor:'#000000', backgroundColor: "#392F2A",alignItems:'center', width:deviceWidth/2 }} onPress={() => Actions.CustomerHome() } >
                    <Image
                      source={require("../../../../assets/icon/home.png")}
                      style={{ width:20, height: 18  }}
                    />
                    <Text style={{fontSize:10, color:'#FFFFFF',paddingTop:10,fontWeight:"bold"}}>Home</Text>
                </View>     
                </TouchableWithoutFeedback>               

                <TouchableWithoutFeedback onPress={() => Actions.profile()}>
                <View style={{ justifyContent:'center', alignItems:'center',  width:deviceWidth/2 }} >
                    <Image
                      source={require("../../../../assets/icon/usercopy.png")}
                      style={{ width:20, height: 20  }}                       
                    />
                    <Text style={{fontSize:10, color:'#707E85',paddingTop:10,fontWeight:"bold"}}>My Profile</Text>
                </View>   
                </TouchableWithoutFeedback>                 
            </View>                

          </View>
          
      </Container>
    );
  }
}


function bindActions(dispatch) {
  return {
    startWalkForAppointment: (id) => dispatch(startWalkForAppointment(id)),
    setActiveLogin: page => dispatch(setActiveLogin(page)),
    connectionState: status => dispatch(connectionState(status)),
    currentLocationUser: () => dispatch(currentLocationUser()),
    clearEntryPageFields: () => dispatch(clearEntryPageFields()),
    selectRole:(role) => dispatch(selectRole(role)),
    customerAppointments:(user_id) => dispatch(customerAppointments(user_id)),
    deleteAppointment: (id) => dispatch(deleteAppointment(id)),
    checkSubscription:() => dispatch(checkSubscription()),
    acceptAppointment:(id) => dispatch(acceptAppointment(id)),
    rejectAppointment:(id) => dispatch(rejectAppointment(id)),
    upcomingBooking:(user_id) => dispatch(upcomingBooking(user_id)),
    setUserLocationNew:(location) => dispatch(setUserLocationNew(location)),
    fetchCustAppointListAsync: user_id => dispatch(fetchCustAppointListAsync(user_id)),
    getNotificationList:() => dispatch(getNotificationList()),
  };
}

export default connect(
  mapStateToProps,
  bindActions
)(Task);
