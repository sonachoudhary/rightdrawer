import { Actions, ActionConst } from "react-native-router-flux";
import React, { Component } from "react";
import { connect } from "react-redux";
import {
  View,
  Platform,
  StatusBar,
  Image,
  Dimensions,
  PermissionsAndroid,
  NetInfo,
  AsyncStorage,
  ImageBackground,
  FlatList,
  TouchableWithoutFeedback,
  ScrollView,
  TouchableOpacity
} from "react-native";
import {
  Container,
  Content,
  Header,
  Text,
  Button,
  Icon,
  Title,
  Left,
  Right,
  Item,
  Body,
  Toast,
  Spinner,
  Thumbnail,
  Grid,
  Col,Input
} from "native-base";
import PropTypes from "prop-types";


import { setActiveLogin } from "../../../actions/common/entrypage";
import { barberAppointments,schoolboardcaste ,getprofilestudentdata} from "../../../actions/common/signin";
import { checkSubscription } from "../../../actions/common/all";
import { acceptAppointment, rejectAppointment, upcomingBooking, setUserLocationNew, startWalkForAppointment, deleteAppointment, getNotificationList } from "../../../actions/common/booking";
import commonColor from "../../../../native-base-theme/variables/commonColor";
import moment from "moment/moment";
import { connectionState } from "../../../actions/network";
import  Footer  from "../../../components/footer";
import {
  clearEntryPage,
  clearEntryPageFields
} from "../../../actions/common/entrypage";

import styles from "./styles";
const deviceHeight = Dimensions.get("window").height;
const deviceWidth = Dimensions.get('window').width;
import { currentLocationUser } from '../../../actions/driver/home';
import { selectRole } from '../../../actions/common/register';
import GetLocation from 'react-native-get-location'
import { customerAppointments } from "../../../actions/common/signin";

  
function mapStateToProps(state) {
  const getErrormsg = () => {
    if (!state.driver.appState.loginError) {
      return "";
    } else return state.driver.appState.errormsg;
  };

  return {
    user: state.driver.user,
    appointmentList: state.booking.appointmentList,
    profileUrl: state.driver.user.profileUrl,
    jwtAccessToken: state.driver.appState.jwtAccessToken,
    username:state.driver.user.student,
  };
}

class SchoolHome extends Component {
  

  constructor(props) {
    super(props);
    console.log('props==',this.props)
    console.log('props==',props)
    this.state = {
      loading: true,
      data:[{image:"../../../../assets/icon/Group_16379.png",subject:'Math',Class:'Class1'},{image:"../../../../assets/icon/Group_16379.png",subject:'Hindi',Class:'Class2'},{image:"../../../../assets/icon/Group_16379.png",subject:'English',Class:'Class3'},{image:"../../../../assets/icon/Group_16379.png",subject:'Science',Class:'Class5'},],
      data2:[{color:"#FEE4C9",Title:'AssignmentTittle',class:'class v',Time:'14:00-mon',desc:' this is project based on react and react js ,node and angular'},{color:"#D6E5FB",Title:'Assignment Tittle',class:'class v',Time:'14:00-mon',desc:' this is project based on react and react js ,node and angular'},{color:"#DEE5DF",Title:'Assignment Tittle',class:'class v',Time:'14:00-mon',desc:' this is project based on react and react js ,node and angular'},{color:"#E6F6E2",Title:'Assignment Tittle',class:'class v',Time:'14:00-mon',desc:' this is project based on react and react js ,node and angular'},{color:"#DEE5DF",Title:'Assignment Tittle',class:'class v',Time:'14:00-mon',desc:' this is project based on react and react js ,node and angular'},{color:"#DEE5DF",Title:'Assignment Tittle',class:'class v',Time:'14:00-mon',desc:' this is project based on react and react js ,node and angular'}],
      customer: {
        latitude: this.props.latitude,
        longitude: this.props.longitude
      },
      showModal:false,
      bookings: this.props.appointmentList,
      modalUserName: undefined,
      modalAppointmentId: undefined,
      modalProfileUrl: undefined,
      status:0,
      isCompleted:undefined,
      isConfirmed:undefined
    };
    
  }
  
  componentDidMount(){
   
    GetLocation.getCurrentPosition({
        enableHighAccuracy: true,
        timeout: 15000,
    })
    .then(location => {
        console.log('getCurrentPosition-',location);
        this.props.setUserLocationNew(location)
    })
    .catch(error => {
        const { code, message } = error;
        console.warn('getCurrentPosition error-', message);
    })
    
    this.props.customerAppointments(this.props.user._id)
  }

  _handleConnectionChange = isConnected => {
    this.props.connectionState({ status: isConnected });
  };
  openInfo(item) {
    console.log('openInfo:',item);
    this.scrollListReftop.scrollTo({x: 0, y: 0, animated: true})
    this.setState({
      showModal: true,
      modalUserName: item.name,
      modalAppointmentId: item.appointment_id,
      services: item.services,
      time: item.time,
      appointment_status: item.status,
      isCompleted: item.isCompleted,
      isConfirmed: item.isConfirmed
    })
  }

  acceptAppointment(id){
    this.setState({
      showModal: false,
    })
    this.props.acceptAppointment(id)
    this.props.barberAppointments(this.props.user._id)
  }

  callBooking(){
    this.props.upcomingBooking(this.props.user._id)
  }

  deleteAppointment(id){
    this.setState({
      showModal: false,
    })
    this.props.deleteAppointment(id);
    this.props.customerAppointments(this.props.user._id)
  }

  startWalk(){  
    this.props.startWalkForAppointment(this.state.modalAppointmentId); 
  }

  renderItem = ({item, index}) => {
    console.log('renderItem:', item.image)
  
     //console.log('renderItem:', path)
    return (
      <TouchableOpacity>
       <View style={styles.Smallbox}>
                { index==0 && <Image source={require("../../../../assets/icon/Group_16379.png")} style={{width:35,height:35}} /> }
                { index==1 && <Image source={require("../../../../assets/images/hindi1.png")} style={{width:35,height:35}} /> }
                { index==2 && <Image source={require("../../../../assets/images/hindi2.png")} style={{width:35,height:35}} /> }
                { index==3 && <Image source={require("../../../../assets/images/hindi3.png")} style={{width:35,height:35}} /> }
                { index==4 && <Image source={require("../../../../assets/images/hindi4.png")} style={{width:35,height:35}} /> }
                { index==5 && <Image source={require("../../../../assets/images/hindi5.png")} style={{width:35,height:35}} /> }


                 </View>
           <Text style={styles.textheading}>{item.subject}</Text>  
           <Text style={styles.subtext}>{item.Class}</Text>  
        </TouchableOpacity>         
               
    )
  };
  renderItem2 = ({item, index}) => {
    console.log('renderItem:', item.image)
  
     //console.log('renderItem:', path)
    return (
      <TouchableOpacity onPress={()=>Actions.Task()} style={{backgroundColor:item.color,margin:10,width:154.13,height:152,borderRadius:10}}>
           
           <Text style={{fontSize:11,marginLeft:10,marginTop:10}}>{item.Time}</Text>  
           <Text style={{fontSize:14,fontWeight:'bold',color:'#000',marginLeft:10}}>{item.Title}</Text> 
            <Text style={{fontSize:12,marginLeft:10,marginTop:10}}>{item.class}</Text> 
            <Text style={{fontSize:12,marginLeft:10,marginTop:10}}>{item.desc}</Text>  
        </TouchableOpacity>         
               
    )
  };

  
  
  render() { 
   console.log(this.props.username,'username')
    return(
      <Container style={{ backgroundColor: "#fff" ,}}>
          
          <Content style={{marginBottom:110}}>
           <ImageBackground source={ require('../../../../assets/images/Mask_Group_37.png')} style={{width: deviceWidth, height: deviceHeight-500, resizeMode:'cover',}}> 
             
               <View style={{flexDirection:'row',justifyContent:'space-between',marginTop:30,marginLeft:20,marginRight:20,}} >
                   <View>
                   {this.props.username &&
                    <Text style={{ color:"#FFF", fontSize:18, fontFamily:'Cabin-Bold'  }}>
                      Hi ,{this.props.username.name}
                    </Text> 
                  }
                    <Text style={{ color:"#FFF", fontSize:16, fontFamily:'Cabin-Bold'  }}>
                      Welcome Back
                    </Text>                    
                  </View>
                   <TouchableOpacity onPress={() => this.props.navigation.openDrawer()} >
                       <Image                      
                      source={require("../../../../assets/images/Group_16692.png")}
                      style={{ width:50.08, height: 50.08, position:'absolute', right:10 , }}
                    />  
                  </TouchableOpacity>

               </View>
                <View style={{ flexDirection:'row', justifyContent:'center', borderColor:'#fff',backgroundColor:'#fff',marginLeft:20,marginRight:20,borderRadius: 10,marginTop:10}} >
                  <Input value = "Search..." style={{  color:'#707070', height:34, width:336, marginLeft:20, marginRight:20, fontSize:14, fontFamily:"Cabin-Regular", opacity:0.7,marginBottom:10 ,}} />
                  <Icon style={{paddingRight:20,paddingTop:7}} name="ios-search" size={20} color="#000"/>             
              </View>
              <View> 
                   <Text style={{ color:"#FFF", fontSize:18,fontFamily:'Cabin-Regular' ,fontWeight:'bold',marginLeft:30,marginTop:10 }}>
                          All Feeds                    
                  </Text>
              </View>
              <View style={styles.box}>
                 <View style={{width:'60%'}}>
                       <Text style={styles.textheading}>
                          School                      
                        </Text>
                         <Text style={{color:"##484347", fontSize:15,fontWeight:'bold',marginLeft:30}}>
                          BoardCast                     
                        </Text>
                        <Text style={styles.subtext}>
                          Lorem ipsum dolor sit amet, consectetue                
                        </Text>
                         <Button
                          style={{backgroundColor:'#DB4C7B',width:88,borderRadius:90,height:26,marginLeft:20,marginTop:10,paddingBottom:5}}
                          >
                         <Text style={{ color: "#fff", fontSize: 11,textalign:'center', }}> View All</Text>
                        </Button>
                 </View>
                 <View style={{width:'40%'}}>
                  <Image
                         source={require("../../../../assets/images/Group_16982.png")}
                         style={{ width:148.04, height: 100.71 }}
                    />

                  </View>
                </View>
           </ImageBackground>
           <View >
                <Text style={{ color:"#333333", fontSize:16,fontWeight:'bold',marginLeft:25,marginTop:60,}}>My Subjects</Text>

           </View>
           <View style={{flexDirection:'row',marginLeft:10,borderBottomWidth:1,borderColor:'lightgray',}}>

                 <View>
                 <View style={styles.Smallbox}>
                    <Image source={require("../../../../assets/icon/Group_16379.png")} style={{width:35,height:35}} /> 
                  </View>
                    <Text style={styles.subtext}>Math</Text>
                    <Text style={styles.subtext2}>Class V</Text>
                </View>
                 <View>
                 <View style={styles.Smallbox}>
                     <Image source={require("../../../../assets/images/hindi1.png")} style={{width:35,height:35}} />
                    </View>
                     <Text style={styles.subtext}>Hindi</Text> 
                     <Text style={styles.subtext2}>Class VII</Text>
                </View>
                 <View>
                 <View style={styles.Smallbox}>
                    <Image source={require("../../../../assets/images/hindi2.png")} style={{width:35,height:35}} /> 
                   </View>
                    <Text style={styles.subtext}>English</Text>
                    <Text style={styles.subtext2}>Class VIII</Text>
                
                </View>
                 <View>
                 <View style={styles.Smallbox}>
                    <Image source={require("../../../../assets/images/hindi3.png")} style={{width:35,height:35}} /> 
                    </View>
                    <Text style={styles.subtext}>Science</Text>
                    <Text style={styles.subtext2}>Class X</Text>
                
                </View>
               </View>
               <View>
                     <Text style={{ color:"#000", fontSize:16,fontWeight:'bold',marginLeft:25,marginTop:15,}}>Submitted Assigment</Text>
                      <FlatList
                        horizontal={true}
                        style={{ margin:10}}
                        data={this.state.data2}
                        extraData={this.state}
                         renderItem={this.renderItem2}
                        
                      />
               </View>
             </Content>
           <Footer />
      </Container>
    );
  }
}


function bindActions(dispatch) {
  return {
    getprofilestudentdata:(data) => dispatch(getprofilestudentdata(data)),
    schoolboardcaste:(data)=>dispatch(schoolboardcaste(data)),
    startWalkForAppointment: (id) => dispatch(startWalkForAppointment(id)),
    setActiveLogin: page => dispatch(setActiveLogin(page)),
    connectionState: status => dispatch(connectionState(status)),
    currentLocationUser: () => dispatch(currentLocationUser()),
    clearEntryPageFields: () => dispatch(clearEntryPageFields()),
    selectRole:(role) => dispatch(selectRole(role)),
    customerAppointments:(user_id) => dispatch(customerAppointments(user_id)),
    deleteAppointment: (id) => dispatch(deleteAppointment(id)),
    checkSubscription:() => dispatch(checkSubscription()),
    acceptAppointment:(id) => dispatch(acceptAppointment(id)),
    rejectAppointment:(id) => dispatch(rejectAppointment(id)),
    upcomingBooking:(user_id) => dispatch(upcomingBooking(user_id)),
    setUserLocationNew:(location) => dispatch(setUserLocationNew(location)),
    fetchCustAppointListAsync: user_id => dispatch(fetchCustAppointListAsync(user_id)),
    getNotificationList:() => dispatch(getNotificationList()),
  };
}

export default connect(
  mapStateToProps,
  bindActions
)(SchoolHome);
