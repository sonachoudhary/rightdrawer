import React, { Component } from "react";
import { connect } from "react-redux";
import { Field, reduxForm } from 'redux-form';
import { Platform, View,Dimensions,Image,TouchableOpacity,AsyncStorage } from "react-native";
import FAIcon from "react-native-vector-icons/FontAwesome";
import PropTypes from "prop-types";
import {
  Container,
  Content,
  Header,
  Text,
  Button,
  Icon,
  Title,
  Left,
  Right,
  Item,
  Spinner,
  Body,
  Toast,
  Input
} from "native-base";
import { Actions } from "react-native-router-flux";
import RegisterFormFb from "../register/formFb";
import * as appStateSelector from "../../../reducers/driver/appState";
//import LoginForm from "./form";
import Register from "../register/";
import { signinAsync } from "../../../actions/common/signin";

import {
  clearEntryPage,
  socailLoginSuccessAndRoutetoRegister,
  socailSignupSuccess
} from "../../../actions/common/entrypage";
import { requestFbLogin } from "../loginFb";
import { signInWithGoogleAsync } from "../loginGoogle";
import { checkUser, userLoginRequest } from "../../../actions/common/checkUser";
import ModalView from "../ModalView";

import styles from "./styles";
import commonColor from "../../../../native-base-theme/variables/commonColor";
import _ from "lodash";
import { changePageStatus, currentLocationUser, signInUser } from '../../../actions/driver/home';
import { fetchUserCurrentLocationAsync, syncDataAsync, mapDeviceIdToUser } from '../../../actions/driver/home';
import OneSignal from "react-native-onesignal";
import config from "../../../../config";
//import DeviceInfo from 'react-native-device-info';

let that = null;
const deviceWidth = Dimensions.get('window').width; 
const validate = values => {
  const errors = {};
  if (!values.email) {
    errors.email = 'Email is required';
  } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)) {
    errors.email = 'Invalid email';
  } else if (isNaN(Number(values.phoneNo))) {
    errors.phoneNo = 'Must be a number';
  } else if (!values.password) {
    errors.password = 'Password is required';
  } else if (!values.phoneNo) {
    errors.phoneNo = 'Mobile number is required';
  } else if (!values.fname) {
    errors.fname = 'First name is required';
  } else if (!values.lname) {
    errors.lname = 'Last name is required';
  }
  if (!values.password) {
    errors.password = 'Password is required';
  }
  return errors;
};

export const input = props => {
  const { meta, input } = props;
  return (
    <View>
      <Item style={{backgroundColor:'#313131',borderRadius:30,paddingLeft:10,borderBottomColor:'#313131',borderBottomWidth:0}}>
        {props.type === 'email' &&
          <Image source={require("../../../../assets/images/email.png")} style={{marginTop:2,marginLeft:5,marginRight:5,opacity:0.9}} />
        }
        {props.type === 'password' &&
          <Image source={require("../../../../assets/images/key.png")} style={{marginTop:2,marginLeft:5,marginRight:5,opacity:0.9}} />
        }
        {props.type === 'user' &&
          <Image source={require("../../../../assets/images/user.png")} style={{marginTop:2,marginLeft:5,marginRight:5,opacity:0.9}} />
        }
        {props.type === 'gender' &&
          <Image source={require("../../../../assets/images/gender.png")} style={{marginTop:2,marginLeft:5,marginRight:5,opacity:0.9}} />
        }
        {props.type === 'date' &&
          <Image source={require("../../../../assets/images/date.png")} style={{marginTop:2,marginLeft:5,marginRight:5,opacity:0.9}} />
        }
        <Input {...input} {...props} style={{ color: '#ffffff',opacity:0.8,height:50,marginTop:-5,borderBottomColor:'#313131',borderBottomWidth:0 }}  />
      </Item>

      {meta.touched && meta.error && <Text style={{ color: 'red' }}>{meta.error}</Text>}
    </View>
  );
};


input.propTypes = {
  input: PropTypes.object,
  meta: PropTypes.object,
};

function mapStateToProps(state) {
  const getErrormsg = () => {
    if (!state.driver.appState.loginError) {
      return "";
    } else return state.driver.appState.errormsg;
  };

  return {
    loadingStatus: state.driver.appState.loadingStatus,
    isLoggedIn: state.driver.appState.isLoggedIn,
    loginError: state.driver.appState.loginError,
    errormsg: appStateSelector.getErrormsg(state),
    isFetching: appStateSelector.isFetching(state),
    socialLogin: state.entrypage.socialLogin,
    appConfig: state.basicAppConfig.config,
    activeLogin: state.entrypage.active,
    tripRequest: state.driver.tripRequest,
    trip: state.driver.trip,
    region: {
      latitude: state.driver.tripRequest.srcLoc[1],
      longitude: state.driver.tripRequest.srcLoc[0],
      latitudeDelta: state.driver.tripRequest.latitudeDelta,
      longitudeDelta: state.driver.tripRequest.longitudeDelta
    },
    driverCurrentGpsLocLat: state.driver.user.gpsLoc[1],
    driverCurrentGpsLocLong: state.driver.user.gpsLoc[0],
    socketDisconnected: state.driver.appState.socketDisconnected,
    latitude: state.driver.user.gpsLoc[1],
    longitude: state.driver.user.gpsLoc[0],
  };
}

class Forgotpassword extends Component {
  static propTypes = {
    loginError: PropTypes.bool,
    errormsg: PropTypes.string,
    isFetching: PropTypes.bool,
    signinAsync: PropTypes.func,
    signInUser: PropTypes.func,
    socailLoginSuccessAndRoutetoRegister: PropTypes.func,
    socailSignupSuccess: PropTypes.func,
    currentLocationDriver: PropTypes.func,
    
  };

  

  constructor(props) {
    super(props);
    
    this.state = {
      socialLogin: null,
      showforgotpanel:false,
      loading: true,
      heading: "RIDER LOCATION ARRIVED",
      displaylabel:'',
      showView: true,
      forgotemail:'',
      customer: {
        latitude: this.props.latitude,
        longitude: this.props.longitude
      },
      driver: {
        latitude: this.props.region.latitude,
        longitude: this.props.region.longitude
      },
      modalVisible: false,
      navigateData: {
        source: {
          latitude: _.get(this.props, "region.latitude", ""),
          longitude: _.get(this.props, "region.longitude", "")
        },
        destination: {
          latitude: _.get(this.props, "driverCurrentGpsLocLat", ""),
          longitude: _.get(this.props, "driverCurrentGpsLocLong", "")
        },
      }
    };

     this.gettimelabel();
    //alert(this.state.customer.latitude+"=="+this.state.customer.longitude);
  }

  UNSAFE_componentWillMount() {
    //OneSignal.init(config.OnesignalAppId);
    OneSignal.init("2b28f1eb-13e9-480d-8f9e-54095b8d9831");
    OneSignal.inFocusDisplaying(2);
    OneSignal.addEventListener("ids", this.onIds);
    OneSignal.addEventListener("received", this.onReceived);
    OneSignal.addEventListener("opened", this.onOpened);
    const { mapDeviceIdToUser, jwtAccessToken } = this.props;
    OneSignal.getPermissionSubscriptionState(status => {
      
      //mapDeviceIdToUser(jwtAccessToken, status.userId, status.pushToken);
    });

    // mapDeviceIdToUser(jwtAccessToken, deviceId, token);
  }

  componentDidMount() {
   
    socketDriverInit();    
    this.props.fetchUserCurrentLocationAsync();
    updateLocation(this.props.user);

  }

  sendforgotpassword() {
    
    if(this.state.forgotemail !=""){
          const obj = {
            email:this.state.forgotemail
        };
        fetch(`${config.serverSideUrl}:${config.port}/api/config/forgot`, {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json"
          },
          body: JSON.stringify(obj)
        })
          .then(resp => resp.json())
          .then(data => {
            alert(data.message);
           
          })
          .catch(e => {
          
           
          });
    } else {
        
    }
     
    

   
  }

  gettimelabel(){
        const userEmail = { appointment_id: 1};
        fetch(`${config.serverSideUrl}:${config.port}/api/users/getdisplaylabel`, { 
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
          },
          body: JSON.stringify(userEmail)
        })
          .then(response => response.json())
          .then(data => { 
                
                this.setState({displaylabel:data.display});
                resolve(data);
          })
          .catch(error => {
            
            
          });
       
    }


  componentWillUnmount() {
    OneSignal.removeEventListener("received", this.onReceived);
    OneSignal.removeEventListener("opened", this.onOpened);
    OneSignal.removeEventListener("ids", this.onIds);
  }

  onIds = device => {
    this.oneSignalDeviceInfo = device;
    
    // alert(device);
  };
  onReceived(notification) {
   
  }
  onOpened(openResult) {
   
  }

  openforgotpassword(){
     this.setState({
      showforgotpanel: true
     })
  }
  closeforgotpassword(){
     this.setState({
      showforgotpanel: false
     })
  }

  async componentDidMount() {
    await this.props.currentLocationUser()
    //await this.props.clearEntryPage();
  }

  async UNSAFE_componentWillReceiveProps() {
    await this.props.currentLocationUser()
    //await this.props.clearEntryPage();
  }

  triggarLocation(){
    this.props.currentLocationUser()
  }

  state = {
    showError: false
  };
  
  async submit(values) {
    
    if(values['email']!=""){
          await AsyncStorage.setItem('forgotPasswordsetEmail',values['email']);
          const obj = {
              email:values['email']
          };
          fetch(`${config.serverSideUrl}:${config.port}/api/config/forgot`, {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json"
            },
            body: JSON.stringify(obj)
          })
            .then(resp => resp.json())
            .then(data => {
              alert(data.message);
              if(data.success==true){
                  Actions.resetpassword();
              }
              
             
            })
            .catch(e => {
            
            });
      }
  }

  
  componentWillReceiveProps(nextProps) {
    
    this.props.currentLocationUser()

    if (nextProps.loginError) {
      this.setState({
        showError: true
      });
    } else {
      this.setState({
        showError: false
      });
    }
    if (nextProps.socialLogin.email !== null) {
      this.setState({ socialLogin: nextProps.socialLogin });
    }
  }

  showLoaderModal() {
    return (
      <ModalView>
        <Spinner />
      </ModalView>
    );
  }

  render() {
    
    return (
      <Container style={{ backgroundColor: "#1A1A1A" }}>
        
        <Content style={{ padding: 10 }} scrollEnabled bounces={false}>
        <View style={{marginTop:30,marginLeft:10}}>
         <TouchableOpacity onPress={() => Actions.signIn()}>
          <Image source={require("../../../../assets/images/leftarrow.png")} style={{width:23,height:16}} />
          </TouchableOpacity>
        </View>
        <View style={{width:deviceWidth,justifyContent:'center',alignItems:'center',marginTop:60,marginBottom:40}}>
          <Image source={require("../../../../assets/images/logo.png")} style={{width:deviceWidth/3,height:deviceWidth/3}} />
        </View>
        <View style={{flexDirection:'row',justifyContent:'center',alignItems:'center', marginTop:10, marginBottom:10}}>
            <Text style={{ fontWeight: "400", fontSize:26,  color: "#cccccc", textAlign: "center",marginRight:0 }}> Forgot </Text>
            <Text style={{ fontWeight: "600", fontSize:26,  color: "#ffffff", textAlign: "center",marginLeft:-2 }}> Password </Text>
        </View>
        <View style={{justifyContent:'center',alignItems:'center', marginTop:10, marginBottom:50}}>
            <Text style={{ width:204,fontWeight: "400", fontSize:16,  color: "#ffffff", textAlign: "center" }}> Recovery code will be sent to your Email Id </Text>
            
        </View>

<View style={{ padding: 10 }}>
            {!this.state.socialLogin && (  
              <View>
              
                <View style={{ padding: 10 }}>
                  <Field
                    component={input}
                    type="email"
                    name="email"
                    placeholder="Enter Your Email"
                    placeholderTextColor={'#686868'}
                    keyboardType="email-address"
                    autoCapitalize="none"
                  />
                </View>
                

                <View style={[styles.regBtnContain,{justifyContent:'center',alignItems:'center',marginTop:40}]}>

                  <Button onPress={this.props.handleSubmit(this.submit.bind(this))} block style={styles.regBtn}>
                    {this.props.isFetching ? (
                      <Spinner />
                    ) : (
                      <Text style={{ color: '#fff', fontWeight: 'bold' }}>Send</Text>
                    )}
                  </Button>
                </View>
                
              </View>
            )}
          
           <View style={{flexDirection:'row',justifyContent:'center',alignItems:'center', marginTop:deviceWidth/3, marginBottom:30,}}>
            <Text style={{ fontWeight: "400", fontSize:14,  color: "#ffffff", textAlign: "center",marginRight:5 }}>
              Already have an account? 
              
            </Text>
            <TouchableOpacity onPress={() => Actions.signIn()}>
                  <Text style={{ fontWeight: "600", fontSize:14,  color: "#ffffff", textAlign: "center" }}> Sign In </Text>
            </TouchableOpacity>
            </View>
              {this.state.showError &&
              Toast.show({
                text: this.props.errormsg,
                position: "bottom",
                duration: 1500
              })}
          </View>
          {this.props.loadingStatus ? this.showLoaderModal() : null}

           

        </Content>

       

      </Container>
    );
  }
}

function bindActions(dispatch) {
  return {
    checkUser: (obj1, obj2) => dispatch(checkUser(obj1, obj2)),
    userLoginRequest: () => dispatch(userLoginRequest()),
    clearEntryPage: () => dispatch(clearEntryPage()),
    socailLoginSuccessAndRoutetoRegister: data =>
      dispatch(socailLoginSuccessAndRoutetoRegister(data)),
    socailSignupSuccess: route => dispatch(socailSignupSuccess(route)),
    signinAsync: (userCredentials, coords) => dispatch(signinAsync(userCredentials, coords)),
    signInUser: userCredentials => dispatch(signInUser(userCredentials)),
    changePageStatus: pageStatus => dispatch(changePageStatus(pageStatus)),
    currentLocationUser: () => dispatch(currentLocationUser()),
    syncDataAsync: jwtAccessToken => dispatch(syncDataAsync(jwtAccessToken)),
    mapDeviceIdToUser: (jwtAccessToken, deviceId, pushToken) => dispatch(mapDeviceIdToUser(jwtAccessToken, deviceId, pushToken))
  };
}

function setCurrentMapDriver() {

  // const gpsLoc = that.props.user.gpsLoc;
  // const obj = {
  //   latitude: gpsLoc[1],
  //   longitude: gpsLoc[0],
  // };
  
}

export { setCurrentMapDriver };

Forgotpassword = reduxForm({
  form: "forgotForm", // a unique name for this form
  validate
})(Forgotpassword);

Forgotpassword = connect(mapStateToProps, bindActions)(Forgotpassword);

export default Forgotpassword;
