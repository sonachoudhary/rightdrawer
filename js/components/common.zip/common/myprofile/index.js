import React, { Component } from "react";
import { connect } from "react-redux";
import { Field, reduxForm } from 'redux-form';
import { Platform, View,Dimensions,Image,TouchableOpacity,ImageBackground } from "react-native";
import FAIcon from "react-native-vector-icons/FontAwesome";
import PropTypes from "prop-types";
import {
  Container,
  Content,
  Header,
  Text,
  Button,
  Icon,
  Title,
  Left,
  Right,
  Item,
  Spinner,
  Body,
  Toast,
  Input
} from "native-base";
import { Actions } from "react-native-router-flux";

import * as appStateSelector from "../../../reducers/driver/appState";
import {DstATopComposition} from 'react-native-image-filter-kit';


import Footer from "../footer";

import styles from "./styles";
import _ from "lodash";

import config from "../../../../config";

let that = null;
const deviceWidth = Dimensions.get('window').width; 
const deviceHeight = Dimensions.get('window').height; 

function mapStateToProps(state) {
   return {
    isLoggedIn:1
   }
}

class Myprofile extends Component {
  static propTypes = { };
  
  constructor(props) {
    super(props);
    this.state = { };
  }

  componentDidMount() { }

  componentWillUnmount() { }

  render() {
     
    return (
      <Container style={{ backgroundColor: "#1A1A1A" }}>
          <View style={{marginTop:50,marginLeft:10,position:'absolute',right:10}}>
             <TouchableOpacity>
              <Image source={require("../../../../assets/images/notification.png")} style={{width:26,height:30}} />
              </TouchableOpacity>
        </View>
        <View style={{width: deviceWidth,justifyContent:'center',alignItems:'center',marginTop:60}}>
            <Text style={{color:'#ffffff',fontSize:20}}>My Profile</Text>
           
        </View>
        <View style={{marginTop:30,justifyContent:'center',alignItems:'center'}}>
            <Image
              resizeMode="contain"
              source={require("../../../../assets/images/user/screenprofile.png")}
              style={{width:deviceWidth-100,height:(deviceHeight-deviceHeight/2)/1.5,zIndex:0,padding:2}}
            />    
        </View>
        
        <View style={{width: deviceWidth,justifyContent:'center',alignItems:'center',marginTop:20}}>
            <Text style={{color:'#ffffff',fontSize:30}}>Jamie Mark, 24</Text>
            <Text style={{color:'#ffffff',fontSize:16,opacity:0.7,marginTop:10}}>Orlando, Florida</Text>
        </View>

        <View style={{width: deviceWidth,justifyContent:'center',alignItems:'center',position:'absolute', bottom:100,flexDirection:'row'}}>
              <View style={{width:80,justifyContent:'center',alignItems:'center'}}>
                <TouchableOpacity onPress={() => Actions.editprofile()}>
                  <Image
                    source={require("../../../../assets/images/edit.png")}
                    style={{borderRadius:30}}
                  />
                </TouchableOpacity>
              </View>
              <View style={{width:80,justifyContent:'center',alignItems:'center'}}>
                 <TouchableOpacity onPress={() => Actions.settings()}>
                  <Image
                    source={require("../../../../assets/images/settings.png")}
                    style={{borderRadius:30}}
                  />
                </TouchableOpacity>
              </View>
              <View style={{width:80,justifyContent:'center',alignItems:'center'}}>
                <Image
                  source={require("../../../../assets/images/share.png")}
                  style={{borderRadius:30}}
                />
              </View>
        </View>
        <Footer />

      </Container>
    );
  }
}

function bindActions(dispatch) {
  return {
    
  };
}

Myprofile = connect(mapStateToProps, bindActions)(Myprofile);

export default Myprofile;
