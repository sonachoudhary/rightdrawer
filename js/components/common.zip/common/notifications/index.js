import React, { Component } from "react";
import { connect } from "react-redux";
import PropTypes from 'prop-types';
import { View, Image, Platform, Dimensions, FlatList, TouchableNativeFeedback as TouchableNative, TouchableOpacity } from "react-native";
import {
  Tab,
  Tabs, 
  ScrollableTab,
  TabHeading,
  Container,
  Header,
  Content,
  Button,
  Icon,
  Card,
  CardItem,
  Thumbnail,
  ListItem,
  Text,
  Item,
  Title,
  Left,
  Right,
  Label,
  Body,
  Spinner
} from "native-base";
import { Actions } from "react-native-router-flux";
import moment from "moment";
import styles from "./styles";
import commonColor from "../../../../native-base-theme/variables/commonColor";
import { getProfileData } from "../../../actions/common/checkUser";
import { fetchNotification, deleteNotification,readNotification,confirmNotification,confirmBooking} from "../../../actions/common/all";
import Modal from "react-native-modal";

const {OS} = Platform;

export const TouchableNativeFeedback = (OS === 'ios') ? TouchableOpacity : TouchableNative;

const { width } = Dimensions.get("window");

function mapStateToProps(state) {
  return {
    jwtAccessToken: state.driver.appState.jwtAccessToken,
    loadSpinner: state.driver.history.loadSpinner,
    newslist: state.customer.newsfeed.newslist,
    user_id: state.driver.user._id,
    userType: state.driver.appState.userType,
    favoriteTrainerList: state.customer.common.favoriteTrainerList,
    notification_list: state.all.notification_list
  };
}

class Notifications extends Component {
  static propTypes = {
    jwtAccessToken: PropTypes.string,
    fetchNotification: PropTypes.func,
    loadSpinner: PropTypes.bool,
    newslist: PropTypes.array,    
  };

  constructor(props) {
    super(props);

    this.state = {
      submit: false,
      image: null,
      render: false,
      //trainerProfileId: this.props.trainerProfileId,
      jwtAccessToken: this.props.jwtAccessToken,
      user_id: this.props.user_id,
      modalVisible: false,
      customerName: '',
      modalDataStatus: '',
      message:'',
      notification_id: undefined 
    };
    
    //this.props.dispatch(getProfileData(this.state.trainerProfileId));    
  }

  setModalVisible(visible,item) { 

      this.props.readNotification(item._id);
     
      if(item.time){
         
         var currenttime = new Date();
         var curnewmmoment = moment(new Date(currenttime)).format("YYYY-MM-DD HH:mm:ss");
     
          
          var setdate = moment(new Date(item.time)).utc(false).format("YYYY-MM-DD HH:mm:ss");
          
           if(curnewmmoment>setdate){
              var expired = 1;
           }else {
              var expired = 0;
           }
          
            if(item && item.SenderData) {
               var name = item.SenderData.fname + " " + item.SenderData.lname;  
              }else {
                 var name = '';
              }

         this.setState({
         	modalVisible: visible,
         	customerName: name,
          picture: item.SenderData.profileUrl,
          customerEmail:item.SenderData.email,
         	message: item.message,
          status: item.status,
          //displaydate: moment(new Date(item.time)).format("MMM Do"),
          //displaydate: moment(new Date(item.time)).format("h:mm A"),
          displaydate: item.time,
          //displaytime: item.time,
          reqService: item.appointment_id.reqService,
          addressdata: item.appointment_id.itemSelected,
          appointmentType: item.appointment_id.bookingtype,
          appointmentStatus: item.appointment_id.status,
          booking_id: item.appointment_id._id,
          trainerProfileId: item.user_id,
         	notification_id: item._id, 
          expired:expired
         });

         
      }
  }

  async componentDidMount() {
    await this.props.fetchNotification(this.state.user_id);
  }

  async fetchAppointmentList() {
    await this.props.fetchNotification(this.state.user_id);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props.userDetails !== nextProps.userDetails) {
      this.setState({
        render: true
      });
    }
  }

  confirmNotification(){
    if(this.state.appointmentType=='group'){
      this.props.confirmBooking(this.state.booking_id,'Confirm');
    }
    if(this.state.appointmentType=='single'){
      this.props.confirmNotification(this.state.booking_id,this.state.trainerProfileId);
    }
  	
    this.fetchAppointmentList()
    this.setState({
     	modalVisible: false
    })
  }
  cancelNotification(){
    // this.setState({ modalVisible: false })
    
    if(this.state.appointmentType=='group'){
      this.props.confirmBooking(this.state.booking_id,'Archive');
    }
    if(this.state.appointmentType=='single'){
      this.props.deleteNotification(this.state.notification_id);
    }
    
    this.fetchAppointmentList();
    this.setState({
      modalVisible: false
    })

  }
  reject(){
    this.fetchAppointmentList();
    this.setState({
      modalVisible: false,
    })
  }

  renderRow = ({ item }) => {  
       
      if(item && item.SenderData) {
       var name = item.SenderData.fname + " " + item.SenderData.lname;  
      }else {
         var name = '';
      }
   
     
  
    var currenttime = new Date();
    var curnewmmoment = moment(new Date(currenttime)).format("YYYY-MM-DD HH:mm:ss");
    var setdate = moment(new Date(item.time)).utc(false).format("YYYY-MM-DD HH:mm:ss");
    if(curnewmmoment>setdate){ var expired = 1; }else { var expired = 0; }

    return (
      <ListItem
        style={styles.listcustom}
      >
      {this.props.userType == "trainer" &&  
       <TouchableNativeFeedback onPress={() => { this.setModalVisible(true,item) }}>
        <View style={styles.outerDiv}>
          <Thumbnail
              source={{ uri: item.SenderData.profileUrl }}
              style={{
              	marginTop:10,
                width: 50,
                height: 50,
                borderRadius: 25,
                borderWidth: 0,
                borderColor: "transparent",
                backgroundColor: "#EFEFEF"
              }} /> 
          <View style={styles.feedDiv} >
	          <Text style={{ flex: 1, textTransform: 'capitalize', textAlign:"left", alignSelf: 'flex-start', alignItems: 'flex-start', color: '#444', fontWeight: '400' }}>{name} </Text>    
	         
            {(item.appointment_id.status=="Pending" && item.unreadstatus==0 && item.status!=1 && expired == 0) &&
              <Text style={ styles.boldnotification }>{ item.message }</Text>  
            }
            {(item.appointment_id.status=="Pending" && item.unreadstatus==1 && item.status!=1 && expired == 0) &&
              <Text style={ styles.notification }>{ item.message }</Text>  
            }
            {(item.appointment_id.status=="Pending" && item.status!=1 && expired == 1) &&
              <Text style={ styles.notification }>Request Expired</Text> 
            }
            {(item.appointment_id.status!='Pending') &&
              <Text style={ styles.notification }>Read</Text> 
            } 

            {(item.appointment_id.status=='Pending' && item.status==1) &&
              <Text style={ styles.notification }>Request Denied</Text> 
            }  

            

          </View>  
          <View style={{marginTop:20}}><Image source={require('../../../../assets/images/arrow-down.png')} style={{width: 30, transform: [{ rotate: '270deg' }], height: 20, marginTop: 20}}/></View>
         </View>
         </TouchableNativeFeedback>
        }
        {this.props.userType == "customer" &&  
        <View style={styles.outerDiv}>
          <Thumbnail
              source={{ uri: item.SenderData.profileUrl }}
              style={{
                marginTop:10,
                width: 50,
                height: 50,
                borderRadius: 25,
                borderWidth: 0,
                borderColor: "transparent",
                backgroundColor: "#EFEFEF"
              }} /> 
          <View style={styles.feedDiv} >
            <Text style={{ flex: 1, textTransform: 'capitalize', textAlign:"left", alignSelf: 'flex-start', alignItems: 'flex-start', color: '#444', fontWeight: '400' }}>{name} </Text>    
              <Text style={ styles.notification }>{ item.message }</Text> 
                     
          </View>  
          </View>
        }
      </ListItem>
    );
  };

 Capitalize(str){
    return str.charAt(0).toUpperCase() + str.slice(1);
 }

  renderEmptyContainer = () => {
    return (        
      <Text style={ styles.emptyMessageStyle }>No Notifications</Text>                  
    );
  };

  render() {
  	
    return (
      <Container style={{ backgroundColor: "#fff" }}>
        <Header
          androidStatusBarColor={commonColor.statusBarColorDark}
          style={Platform.OS === "ios" ? styles.iosHeader : styles.aHeader}
        >
          <Left>
            <Button transparent onPress={() => Actions.pop()}>
              <Icon
                name="md-arrow-back"
                style={{ fontSize: 28, color: "#fff" }}
              />
            </Button>
          </Left>
          <Body>
            <Title
              style={
                Platform.OS === "ios"
                  ? styles.iosHeaderTitle
                  : styles.aHeaderTitle
              }
            >
              Notifications
            </Title>
          </Body>
          <Right/>            
        </Header>
        
        <Content style={{ backgroundColor: "#FFFFFF" }}>
          <View>
            <FlatList
              data={this.props.notification_list}
              renderItem={this.renderRow}
              style={{ borderTopWidth: 2, borderTopColor: "#ddd" }}
              ListEmptyComponent={this.renderEmptyContainer()}
              />
          </View>
          
          <Modal
              animationType="slide"
              visible={this.state.modalVisible}
              onRequestClose={() => {
                Alert.alert('Modal has been closed');
              }}>

                    <View style={styles.modalView}>
                      
                         <View style={{ position:'absolute',right:15,flex:1,marginTop:15}}>
                           <TouchableOpacity onPress={() => this.reject() }> 
                              <Image source={require('../../../../assets/images/arrow-down.png')} style={{ padding:10,width: 50,height: 50,marginTop:0,right:15}}/>
                            </TouchableOpacity> 
                          </View>

                        <Text style={{ color: "#000",fontSize:24, marginTop:80, textAlign:"center",textTransform:'capitalize' }}>
                          {this.state.customerName}
                        </Text>
                             <Text style={{ color: "#A2A2A2", fontSize:14,marginBottom:10, textAlign:"center" }}>
                           {this.state.customerEmail}
                        </Text>
                         <View style={{borderRadius:40}}>
                         <Image source={{ uri: this.state.picture }} style={{width: 80, height: 80,backgroundColor: "#EFEFEF",borderRadius:40,alignSelf: 'center',}}/>
                         </View>
                        {this.state.reqService!=undefined &&
                            <Text style={styles.messagedata}>
                                {this.Capitalize(this.state.customerName)} is requesting {this.state.reqService} training on: 
                            </Text>
                        }
                        {this.state.reqService==undefined &&
                            <Text style={styles.messagedata}>
                               {this.Capitalize(this.state.customerName)} is requesting training on: 
                            </Text>
                        }
                        <Text style={{ color: "#000", marginTop:10, fontSize:26, textAlign:"center" }}>
                            {moment(this.state.displaydate).utc(false).format('lll')}
                        </Text>

                        <Text style={{ color: "#000", marginTop:10, textAlign:"center" }}>
                        Requested Session:
                        </Text>
                        <Text style={{ color: "#000", textAlign:"center" }}>
                         {this.state.addressdata}
                        </Text>
                       
                        <Text style={{ color: "#000", marginTop:10, fontSize:22, textAlign:"center" }}>
                        {this.state.distance}
                        </Text>
                    
                    {(this.state.appointmentStatus=="Pending" && this.state.status!=1 && this.state.expired == 0) &&
                      
                          <Button
                            block
                            style={styles.deleteBtn}
                             onPress={() => this.confirmNotification() }
                             >
                            <Text style={{ alignSelf: "center", color: "#ffffff" }}>
                              ACCEPT              
                            </Text>
                          </Button>
                    }
                    {(this.state.appointmentStatus=="Confirm") &&
                       <Text style={{ color: "#000", marginTop:20, fontSize:18, textAlign:"center" }}>
                           Request Accepted
                        </Text>
                     }
                    {(this.state.appointmentStatus=="Pending" && this.state.status!=1 && this.state.expired == 1) &&
                       <Text style={{ color: "#000", marginTop:20, fontSize:18, textAlign:"center" }}>
                           Appointment Expired
                        </Text>
                     }
                     {(this.state.appointmentStatus=="Archive" || this.state.status==1) &&
                       <Text style={{ color: "#000", marginTop:20, fontSize:18, textAlign:"center" }}>
                          Request Denied
                        </Text>
                     }
                    {(this.state.appointmentStatus=="Pending" && this.state.status!=1  && this.state.expired == 0) &&
                      <Button
                        block
                        style={styles.cancelBtn}
                       onPress={() => this.cancelNotification() } 
                      >
                        <Text style={{ alignSelf: "center", color: "#ffffff" }}>
                          DECLINE              
                        </Text>
                      </Button>
                    }


                        <Button
                        block
                        style={[styles.cancelBtn,{marginTop:50,backgroundColor: "#EFEFEF"}]}
                       onPress={() => this.reject() } 
                      >
                        <Text style={{ alignSelf: "center", color: "#000000" }}>
                          CLOSE              
                        </Text>
                      </Button>

                </View>

                
                  

                  
             
          </Modal>
        </Content>        
        
      </Container>
    );
  }
}

function bindActions(dispatch) {
  return {
    fetchNotification: user_id => dispatch(fetchNotification(user_id)),
    deleteNotification: notification_id => dispatch(deleteNotification(notification_id)),
    readNotification: notification_id => dispatch(readNotification(notification_id)),
    confirmNotification: (booking_id,trainerProfileId) => dispatch(confirmNotification(booking_id,trainerProfileId)),
    confirmBooking: (booking_id,status) => dispatch(confirmBooking(booking_id,status)),
  };
}

export default connect(
  mapStateToProps,
  bindActions
)(Notifications);