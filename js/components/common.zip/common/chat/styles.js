import commonColor from '../../../../native-base-theme/variables/commonColor';
const React = require('react-native');

const { Dimensions } = React;

const deviceHeight = Dimensions.get('window').height;
const deviceWidth = Dimensions.get('window').width;

export default {
  iosHeader: {
    backgroundColor: commonColor.brandPrimary
  },
  aHeader: {
    backgroundColor: commonColor.brandPrimary,
    borderColor: "#FFF",
    elevation: 3
  },
  outer: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'space-between',
    backgroundColor: 'white',
    minHeight:250,
  },
  outerand:{
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'space-between',
    backgroundColor: 'white',
    minHeight:deviceHeight/3,
    marginBottom:deviceHeight/9,
  },
  iosHeaderTitle: {
    fontSize: 18,
    fontWeight: "500",
    color: "#fff",
    marginLeft: 10,
  },
  aHeaderTitle: {
    fontSize: 18,
    fontWeight: "500",
    lineHeight: 26,
    marginTop: -5,
    color: "#fff",
    marginLeft: 5,
  },
  
  messages: {
    flex: 1,
    height: deviceHeight - 170,
    marginRight:10
  },

  //InputBar

  inputBar: {
    flexDirection: 'row',
    
    paddingHorizontal: 5,
    paddingVertical: 3,
    marginBottom:15,
    justifyContent: 'flex-end',
  },
  inputBarand:{
    flexDirection: 'row',
    marginBottom:15,
    paddingHorizontal: 5,
    paddingVertical: 3,
    bottom:0,
    position: 'absolute',
  },
  textBox: {
    borderRadius: 5,
    borderWidth: 1,
    borderColor: 'gray',
    flex: 1,
    fontSize: 16,
    paddingHorizontal: 10
  },

  sendButton: {
    justifyContent: 'center',
    alignItems: 'center',
    paddingLeft: 15,
    marginLeft: 5,
    paddingRight: 15,
    borderRadius: 5,
    backgroundColor: '#1C2331'
  },

  //MessageBubble

  messageBubble: {
      borderRadius: 10,
      marginTop: 8,
      marginRight: 10,
      marginLeft: 10,
      paddingHorizontal: 10,
      paddingVertical: 5,    
      width:'auto'
  },

  messageBubbleLeft: {
    backgroundColor: '#ffffff',
    borderWidth:1,
    borderColor:'#b3b3b3'
  },

  messageBubbleTextLeft: {
    color: 'black'
  },

  messageBubbleRight: {
    backgroundColor: '#e6e6e6',
    paddingRight: 30,
  },

  messageBubbleTextRight: {
    color: '#000000',
    paddingRight: 30,
  },
  headerPicView: {
    flex:1,
    width:40,    
  },
  headerUserPic: {
    height: 50,
    width: 50,
    margin: 5,
    borderRadius: 25,
    paddingLeft:10,
  },
  showmessageBubble:{
    color: '#777777',
    fontSize:10
  }
};
