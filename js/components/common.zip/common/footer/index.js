import React, { Component } from "react";
import { connect } from "react-redux";
import { Field, reduxForm } from 'redux-form';
import { Platform, View,Dimensions,Image,TouchableOpacity } from "react-native";
import FAIcon from "react-native-vector-icons/FontAwesome";
import PropTypes from "prop-types";
import {
  Container,
  Content,
  Header,
  Text,
  Button,
  Icon,
  Title,
  Left,
  Right,
  Item,
  Spinner,
  Body,
  Toast,
  Input
} from "native-base";
import { Actions } from "react-native-router-flux";
import RegisterFormFb from "../register/formFb";
import * as appStateSelector from "../../../reducers/driver/appState";
//import LoginForm from "./form";
import Register from "../register/";
import { signinAsync } from "../../../actions/common/signin";

import {
  clearEntryPage,
  socailLoginSuccessAndRoutetoRegister,
  socailSignupSuccess
} from "../../../actions/common/entrypage";
import { requestFbLogin } from "../loginFb";
import { signInWithGoogleAsync } from "../loginGoogle";
import { checkUser, userLoginRequest } from "../../../actions/common/checkUser";
import ModalView from "../ModalView";

import styles from "./styles";
import commonColor from "../../../../native-base-theme/variables/commonColor";
import _ from "lodash";
import { changePageStatus, currentLocationUser, signInUser } from '../../../actions/driver/home';
import { fetchUserCurrentLocationAsync, syncDataAsync, mapDeviceIdToUser } from '../../../actions/driver/home';
import OneSignal from "react-native-onesignal";
import config from "../../../../config";
//import DeviceInfo from 'react-native-device-info';

let that = null;
const deviceWidth = Dimensions.get('window').width; 
const deviceHeight = Dimensions.get('window').height; 

   
      const setFooter = ({ }: Props) => (
        <View style={{width: deviceWidth, height: 45, flexDirection:'row', justifyContent:'center', position:'absolute', bottom:10}} >
          <View style={{ justifyContent:'center', paddingTop:5,alignItems:'center', width:deviceWidth/4 }} >
            <Button transparent onPress={() => Actions.preferencelist()} >
               <Image source={require("../../../../assets/images/home.png")} />
            </Button>
          </View>                    

          <View style={{ justifyContent:'center', paddingTop:5,alignItems:'center', width:deviceWidth/4, paddingLeft:15 }} >
            <Button transparent onPress={() => Actions.signIn()} >
                <Image source={require("../../../../assets/images/chat.png")} />
            </Button> 
          </View>                    

          <View style={{ justifyContent:'center', paddingTop:5,alignItems:'center',  width:deviceWidth/4 , paddingLeft:25}} >
            <Button transparent onPress={() => Actions.myprofile()} >
              <Image source={require("../../../../assets/images/user_footer.png")} />
            </Button>
          </View>                    
      </View> 
  );
export default setFooter;
